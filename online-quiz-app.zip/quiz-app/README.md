# Online Quiz Application (React + Vite)

## Run
    npm install
    npm run dev

## Views
1. Home - name form with validation, category and question count
2. Quiz - one question at a time, answer validation, 20s timer, instant feedback
3. Result - score, percentage, answer review, retry
4. Questions - add / edit / delete / search / filter (saved in localStorage)
