import { useEffect, useState } from "react";
import { defaultQuestions } from "./questions.js";
import Home from "./components/Home.jsx";
import Quiz from "./components/Quiz.jsx";
import Result from "./components/Result.jsx";
import ManageQuestions from "./components/ManageQuestions.jsx";

const loadQuestions = () => {
  try {
    const saved = JSON.parse(localStorage.getItem("quiz-questions"));
    return Array.isArray(saved) && saved.length ? saved : defaultQuestions;
  } catch {
    return defaultQuestions;
  }
};

export default function App() {
  const [view, setView] = useState("home"); // home | quiz | result | manage
  const [questions, setQuestions] = useState(loadQuestions);
  const [player, setPlayer] = useState({ name: "", category: "All" });
  const [quizSet, setQuizSet] = useState([]);
  const [answers, setAnswers] = useState([]);

  useEffect(() => {
    localStorage.setItem("quiz-questions", JSON.stringify(questions));
  }, [questions]);

  const startQuiz = (info) => {
    const pool = info.category === "All" ? questions : questions.filter((q) => q.category === info.category);
    const shuffled = [...pool].sort(() => Math.random() - 0.5).slice(0, info.count);
    setPlayer(info);
    setQuizSet(shuffled);
    setView("quiz");
  };

  const finishQuiz = (result) => {
    setAnswers(result);
    setView("result");
  };

  return (
    <div className="app">
      <header className="topbar">
        <h1 onClick={() => setView("home")}>QuizBoard</h1>
        <nav>
          <button className={view === "home" ? "tab active" : "tab"} onClick={() => setView("home")}>Play</button>
          <button className={view === "manage" ? "tab active" : "tab"} onClick={() => setView("manage")}>Questions</button>
        </nav>
      </header>
      <main>
        {view === "home" && <Home questions={questions} onStart={startQuiz} />}
        {view === "quiz" && <Quiz questions={quizSet} onFinish={finishQuiz} />}
        {view === "result" && (
          <Result player={player} questions={quizSet} answers={answers} onRetry={() => startQuiz(player)} onHome={() => setView("home")} />
        )}
        {view === "manage" && <ManageQuestions questions={questions} setQuestions={setQuestions} />}
      </main>
    </div>
  );
}
