export const CATEGORIES = ["React", "JavaScript", "HTML & CSS"];

export const defaultQuestions = [
  { id: 1, category: "React", text: "Which hook is used to manage state in a function component?", options: ["useEffect", "useState", "useRef", "useMemo"], correct: 1 },
  { id: 2, category: "React", text: "What does JSX stand for?", options: ["JavaScript XML", "Java Syntax Extension", "JSON XML", "JavaScript Extra"], correct: 0 },
  { id: 3, category: "React", text: "Which hook runs side effects after render?", options: ["useState", "useContext", "useEffect", "useReducer"], correct: 2 },
  { id: 4, category: "JavaScript", text: "Which keyword declares a block-scoped constant in ES6?", options: ["var", "let", "def", "const"], correct: 3 },
  { id: 5, category: "JavaScript", text: "What does Array.prototype.map() return?", options: ["A new array", "The original array", "A single value", "undefined"], correct: 0 },
  { id: 6, category: "JavaScript", text: "What is the output of typeof null?", options: ["null", "undefined", "object", "number"], correct: 2 },
  { id: 7, category: "HTML & CSS", text: "Which CSS feature creates a responsive two-dimensional layout?", options: ["Float", "Grid", "Position", "Inline-block"], correct: 1 },
  { id: 8, category: "HTML & CSS", text: "Which HTML5 tag defines navigation links?", options: ["<nav>", "<section>", "<aside>", "<menu>"], correct: 0 },
];
