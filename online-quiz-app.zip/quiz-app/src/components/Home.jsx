import { useState } from "react";
import { CATEGORIES } from "../questions.js";

export default function Home({ questions, onStart }) {
  const [name, setName] = useState("");
  const [category, setCategory] = useState("All");
  const [count, setCount] = useState(5);
  const [error, setError] = useState("");

  const available = category === "All" ? questions.length : questions.filter((q) => q.category === category).length;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name.trim().length < 2) return setError("Enter your name (at least 2 characters).");
    if (available === 0) return setError("This category has no questions. Add some under Questions.");
    setError("");
    onStart({ name: name.trim(), category, count: Math.min(Number(count), available) });
  };

  return (
    <section className="card narrow">
      <h2>Ready for a quick quiz?</h2>
      <p className="muted">Answer each question, check it, and see your score at the end.</p>
      <form onSubmit={handleSubmit} noValidate>
        <label>Your name
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Priya" />
        </label>
        <label>Category
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            <option>All</option>
            {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </label>
        <label>Number of questions ({available} available)
          <input type="number" min="1" max={Math.max(available, 1)} value={count} onChange={(e) => setCount(e.target.value)} />
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="primary" type="submit">Start quiz</button>
      </form>
    </section>
  );
}
