import { useEffect, useState } from "react";

const TIME_PER_QUESTION = 20;

export default function Quiz({ questions, onFinish }) {
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [checked, setChecked] = useState(false);
  const [error, setError] = useState("");
  const [timeLeft, setTimeLeft] = useState(TIME_PER_QUESTION);
  const [answers, setAnswers] = useState([]);

  const q = questions[index];
  const isLast = index === questions.length - 1;

  // Countdown timer: runs while the question is unanswered
  useEffect(() => {
    if (checked) return;
    if (timeLeft === 0) {
      lockAnswer(selected);
      return;
    }
    const t = setTimeout(() => setTimeLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [timeLeft, checked]);

  const lockAnswer = (choice) => {
    setChecked(true);
    setError("");
    setAnswers((prev) => [...prev, choice]); // null = unanswered
  };

  const handleCheck = () => {
    if (selected === null) return setError("Pick an option before checking your answer.");
    lockAnswer(selected);
  };

  const handleNext = () => {
    if (isLast) return onFinish(answers);
    setIndex(index + 1);
    setSelected(null);
    setChecked(false);
    setTimeLeft(TIME_PER_QUESTION);
  };

  if (!q) return <p className="card narrow">No questions to show.</p>;

  return (
    <section className="card narrow">
      <div className="meta">
        <span>Question {index + 1} of {questions.length}</span>
        <span className={timeLeft <= 5 && !checked ? "timer low" : "timer"}>{timeLeft}s</span>
      </div>
      <div className="progress"><div style={{ width: `${(index / questions.length) * 100}%` }} /></div>
      <h2>{q.text}</h2>
      <div className="options">
        {q.options.map((opt, i) => {
          let cls = "option";
          if (!checked && selected === i) cls += " selected";
          if (checked && i === q.correct) cls += " correct";
          if (checked && selected === i && i !== q.correct) cls += " wrong";
          return (
            <button key={i} className={cls} disabled={checked} onClick={() => { setSelected(i); setError(""); }}>
              {opt}
            </button>
          );
        })}
      </div>
      {error && <p className="error" role="alert">{error}</p>}
      {checked && (
        <p className={selected === q.correct ? "feedback good" : "feedback bad"}>
          {selected === null ? "Time's up." : selected === q.correct ? "Correct." : `Not quite. The answer is "${q.options[q.correct]}".`}
        </p>
      )}
      {!checked
        ? <button className="primary" onClick={handleCheck}>Check answer</button>
        : <button className="primary" onClick={handleNext}>{isLast ? "See results" : "Next question"}</button>}
    </section>
  );
}
