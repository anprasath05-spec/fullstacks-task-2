import { useState } from "react";
import { CATEGORIES } from "../questions.js";

const emptyForm = { text: "", options: ["", "", "", ""], correct: 0, category: CATEGORIES[0] };

export default function ManageQuestions({ questions, setQuestions }) {
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");

  const setOption = (i, value) => setForm({ ...form, options: form.options.map((o, j) => (j === i ? value : o)) });

  const validate = () => {
    if (form.text.trim().length < 5) return "Question text must be at least 5 characters.";
    if (form.options.some((o) => !o.trim())) return "Fill in all four options.";
    if (new Set(form.options.map((o) => o.trim().toLowerCase())).size < 4) return "Options must be different from each other.";
    return "";
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const msg = validate();
    if (msg) return setError(msg);
    const clean = { ...form, text: form.text.trim(), options: form.options.map((o) => o.trim()) };
    if (editingId) setQuestions(questions.map((q) => (q.id === editingId ? { ...clean, id: editingId } : q)));
    else setQuestions([...questions, { ...clean, id: Date.now() }]);
    setForm(emptyForm);
    setEditingId(null);
    setError("");
  };

  const handleEdit = (q) => {
    setForm({ text: q.text, options: [...q.options], correct: q.correct, category: q.category });
    setEditingId(q.id);
    setError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = (id) => {
    if (!window.confirm("Delete this question?")) return;
    setQuestions(questions.filter((q) => q.id !== id));
    if (editingId === id) { setEditingId(null); setForm(emptyForm); }
  };

  const visible = questions.filter(
    (q) => (filter === "All" || q.category === filter) && q.text.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="grid">
      <section className="card">
        <h2>{editingId ? "Edit question" : "Add a question"}</h2>
        <form onSubmit={handleSubmit} noValidate>
          <label>Question
            <textarea rows="2" value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} />
          </label>
          <label>Category
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
          {form.options.map((o, i) => (
            <label key={i} className="optrow">
              <input type="radio" name="correct" checked={form.correct === i} onChange={() => setForm({ ...form, correct: i })} aria-label={`Mark option ${i + 1} correct`} />
              <input value={o} placeholder={`Option ${i + 1}`} onChange={(e) => setOption(i, e.target.value)} />
            </label>
          ))}
          <p className="muted small">Select the radio button beside the correct option.</p>
          {error && <p className="error" role="alert">{error}</p>}
          <div className="row">
            <button className="primary" type="submit">{editingId ? "Save changes" : "Add question"}</button>
            {editingId && <button type="button" className="secondary" onClick={() => { setEditingId(null); setForm(emptyForm); }}>Cancel</button>}
          </div>
        </form>
      </section>

      <section className="card">
        <h2>Question bank ({visible.length})</h2>
        <div className="row">
          <input placeholder="Search questions" value={search} onChange={(e) => setSearch(e.target.value)} />
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option>All</option>
            {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        {visible.length === 0 && <p className="muted">No questions match. Adjust the search or add a new one.</p>}
        <ul className="bank">
          {visible.map((q) => (
            <li key={q.id}>
              <div><strong>{q.text}</strong><span className="tag">{q.category}</span></div>
              <div className="row">
                <button className="secondary small" onClick={() => handleEdit(q)}>Edit</button>
                <button className="danger small" onClick={() => handleDelete(q.id)}>Delete</button>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
