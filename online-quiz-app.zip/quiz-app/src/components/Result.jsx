export default function Result({ player, questions, answers, onRetry, onHome }) {
  const score = questions.reduce((n, q, i) => n + (answers[i] === q.correct ? 1 : 0), 0);
  const percent = Math.round((score / questions.length) * 100);
  const message = percent >= 80 ? "Excellent work." : percent >= 50 ? "Good effort. Review the misses below." : "Keep practising. Try again.";

  return (
    <section className="card">
      <h2>{player.name}, you scored {score} out of {questions.length}</h2>
      <p className="big">{percent}%</p>
      <p className="muted">{message}</p>
      <ul className="review">
        {questions.map((q, i) => {
          const ok = answers[i] === q.correct;
          return (
            <li key={q.id} className={ok ? "ok" : "miss"}>
              <strong>{q.text}</strong>
              <span>Your answer: {answers[i] == null ? "No answer" : q.options[answers[i]]}</span>
              {!ok && <span>Correct answer: {q.options[q.correct]}</span>}
            </li>
          );
        })}
      </ul>
      <div className="row">
        <button className="primary" onClick={onRetry}>Retry quiz</button>
        <button className="secondary" onClick={onHome}>Back to start</button>
      </div>
    </section>
  );
}
